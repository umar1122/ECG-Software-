function varargout = FileRead(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FileRead_OpeningFcn, ...
                   'gui_OutputFcn',  @FileRead_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FileRead is made visible.
function FileRead_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


function varargout = FileRead_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

function selectButton_Callback(hObject, eventdata, handles)
[filename, pathname] = uigetfile({'*.*'}, 'File Selector');
global globl_filename;
globl_filename= filename;
[fPath, fName, fExt] = fileparts(globl_filename);
switch lower(fExt)
     % .txt file
     case '.txt'
        data = importdata(globl_filename);
        x = data(:, 1);
        y = data(:, 2);
        plot(x, y, 'b-', 'LineWidth',0.01);
        title('ECG Signal', 'FontSize', 15);
        xlabel(app.UIAxes, 'Time', 'FontSize', 10);
        ylabel(app.UIAxes,'Voltage', 'FontSize', 10);
        grid on;
        plot(handles.axes1, x, y, 'b-', 'LineWidth', 0.01);
        title(handles.axes1, 'ECG Signal', 'FontSize', 15);
        xlabel(handles.axes1, 'Time (s)', 'FontSize', 12); % Set x label
        ylabel(handles.axes1, 'Voltage (V)', 'FontSize', 12); % Set y label
        grid(handles.axes1, 'on');
        set(handles.axes1,'XColor',[0 0 0],'YColor',[0 0 0]); % Set axis color to black
        
    % .mat file    
     case '.mat'
        val = importdata(globl_filename);
        ECGsignal = (val - 0)/200;  %(val - base)/gain (we got them from info file with the downloaded data)
        fs = 360;                    % Sampling frequency
        n = length(ECGsignal);
        t = (0 : n-1)/fs;
        plot(t, ECGsignal);
 
  otherwise  
    error('Unexpected file extension: %s', fExt);
    
end
sig = importdata(globl_filename);

% Remove trend from data
detrendedECG = detrend(sig);

beat_count = 0;

for k = 2 : length(sig)-1
    if(sig(k) > sig(k-1) && sig(k) > sig(k+1) && sig(k) > 1)
        beat_count = beat_count + 1;
    end
end

% Divide the beats counted by the signal duration
fs = 360;                  % Sampling frequency
N = length(detrendedECG);

duration_in_seconds = N/fs;
PPS_avg = beat_count/duration_in_seconds;

duration_in_minutes = duration_in_seconds/60;
BPM_avg = beat_count/duration_in_minutes;
set(handles.res_in_sec, 'String', PPS_avg); % showing pulse per second
set(handles.res_per_min, 'String', BPM_avg); % showing beats per minute
global pulse;
pulse=BPM_avg;

if pulse > 100
    set(handles.notification, 'String', "This Patient has tachycardia as heart rate is above 120 beats per minute");
    set(handles.notification, 'ForegroundColor', [1, 0, 0]); % Set text color to red
elseif pulse < 60
    set(handles.notification, 'String', "This Patient has bradycardia as heart rate is below 60 beats per minute");
    set(handles.notification, 'ForegroundColor', [1, 0, 0]); % Set text color to light blue
else
    set(handles.notification, 'String', "This Person is normal and there is no problem");
    set(handles.notification, 'ForegroundColor', [0, 1, 0]); % Set text color to black
end
